import UIKit

var greeting = "Hello, playground"

print("Hii",10,12.25)

print("Hi", 10, 15) // comma gives o/p in the result

//print statement using String Interpolation
//example 1
var programmingLanguage = "Swift"
print("My favorite programming language is \(programmingLanguage)")

//example 2
var object = "NWMSU"
var grade = 90
var language = "swift"
print("im studying in, \(object)")
print("im studying in, \(object) my grade is \(grade)")
print("im studying in Nwmsu, i hate \(language)")

//example 3
var age = 28
print("You are \(age) years old and in another \(age) years, you will be \(age * 2)")

//example 4
print("""
Hello
World!
vjhsvfhkSVFWS
KJbwljgbwV
KWjrbvfewfwefwef
""")

print ("Hello All,\rWelcome to Swift programming")

print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")


print("Welcome to Swift Programming" , terminator : ":-" )
print("Fall 2021")


//In general, the items in a print statement are separated by spaces, to print the items separated by something other than spaces, we use separator
print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is" ,  terminator: ":-")
print(1,2,3,4,5,6, separator: "-")
print(1,2,3,4,5,6, separator: "$ ,")


//Declaration of variable
var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)

let pi = 3.14
print(4.23)


var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")


var circulam01 = "iOS"
var circulam02 = "Java"
print(circulam01,circulam02)
print(circulam01,"-",circulam02)

print(10,20,30,75.6, terminator: " ")
print(12.5,15.5,90.88)


//Tuples
//example1

var httpError  = (errorCode : 404  , errorMessage : "PageNot Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )
                  
//example2
var region  = (Name : "Homakesavadurgaprasad"  , from : "India")
print(region)
print(region.Name , terminator : ": ")
print(region.from )

//example3
var name = ("John","Smith")
var fName = name.0
var lName = name.1
print(fName , terminator : ",")
print(lName)

var details = ("India","AndhraPradesh")
var get01 = details.0
var get02 = details.1
print(get01, terminator: ",")
print(get02)

//example 4
var origin = (x : 0 , y : 0)
var point = origin
print(point)


var command = (g : 5.7, h : 6.8)
var year = command
print(year

//example5
//let city = (name : "Maryville" , population : 11,000)
//let (cityName ,cityPopulation ) = (city.0 , city.1)
//print(cityName)
//print(cityPopulation)

//let foreigncountry = (name : "USA", population : 30,000)
//let (foreigncountryname, foreigncountrypopulation) = (foreigncountry.0 , foreigncountry.1)
//print(foreigncountry)
